package com.example.voice2text

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.speech.*
import android.speech.SpeechRecognizer
import android.widget.*
import android.text.ClipboardManager
import java.util.*

class MainActivity : Activity() {
    private lateinit var sr: SpeechRecognizer
    private lateinit var out: TextView
    private lateinit var lang: Spinner
    private var listening=false
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        out=findViewById(R.id.out); lang=findViewById(R.id.lang)
        val langs=arrayOf("မြန်မာ (my-MM)","English (en-US)")
        lang.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs)
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),7)
        sr=SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object: RecognitionListener {
            override fun onResults(r: Bundle?) {
                val a=r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if(!a.isNullOrEmpty()) out.append(a[0]+" ")
                if(listening) startListening()
            }
            override fun onError(e:Int){ if(listening) startListening() }
            override fun onReadyForSpeech(p:Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v:Float) {}
            override fun onBufferReceived(b:ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b:Bundle?) {}
            override fun onEvent(t:Int,b:Bundle?) {}
        })
        findViewById<Button>(R.id.start).setOnClickListener { listening=true; startListening() }
        findViewById<Button>(R.id.stop).setOnClickListener { listening=false; sr.stopListening() }
        findViewById<Button>(R.id.copy).setOnClickListener {
            val cm=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("စာ",out.text)); Toast.makeText(this,"Copy ပြီးပါပြီ",Toast.LENGTH_SHORT).show()
        }
    }
    private fun startListening(){
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,if(lang.selectedItemPosition==0)"my-MM" else "en-US")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true)
        sr.startListening(i)
    }
    override fun onDestroy(){ listening=false; sr.destroy(); super.onDestroy() }
}
